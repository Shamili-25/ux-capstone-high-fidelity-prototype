# How to Upload to GitHub & Get Your Link

## Option A — Website (easiest, no coding)
1. Sign in at github.com → click **+** → **New repository**
2. Name: `ux-capstone-project` · Public · (don't add README, we have one)
3. Click **Create repository**
4. Click **"uploading an existing file"**
5. Unzip this folder, drag **all contents** into the page
6. Commit message: `Initial commit: UX capstone` → **Commit changes**
7. Your link: `https://github.com/<your-username>/ux-capstone-project`

## Option B — Git command line
```bash
cd ux-capstone-project
git init
git add .
git commit -m "Initial commit: UX capstone"
git branch -M main
git remote add origin https://github.com/<your-username>/ux-capstone-project.git
git push -u origin main
```

## After uploading
- Add the repo description + topics: `ux`, `ui-design`, `figma`, `case-study`
- Update README proof links
- Add exported screenshots to `assets/` and commit again
