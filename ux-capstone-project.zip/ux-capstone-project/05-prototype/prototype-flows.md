# Interactive Prototype Specification

**Figma Prototype Link:** `PASTE LINK` (Share → Prototype → set to "Anyone with the link can view")

## Flows
| Flow | Path |
|---|---|
| Onboarding | Splash → Onboarding 1 → 2 → 3 → Sign Up → Home |
| Core Task | Home → Detail → Step 1 → Step 2 → Confirmation |
| Profile | Home → Profile → Settings → Toggle |
| Error recovery | Any form → Error state → Retry |

## Interaction Map
| Trigger | Element | Action | Animation | Duration |
|---|---|---|---|---|
| On click | Primary CTA | Navigate to next screen | Smart Animate, ease-out | 300ms |
| On click | Card | Open Detail | Move In (right) / Smart Animate hero | 400ms |
| On click | FAB / Filter | Open Overlay (bottom sheet) | Move In (bottom) | 300ms |
| On click | Modal "Confirm" | Close overlay + Toast | Dissolve | 200ms |
| While hovering / pressed | Buttons | Change to variant: Pressed | Smart Animate | 150ms |
| On drag | Onboarding carousel | Swipe to next | Smart Animate | 300ms |
| After delay | Splash | Auto-navigate to Onboarding | Dissolve | 1500ms |
| On click | Toggle | Variant On ↔ Off | Smart Animate | 200ms |

## Micro-interactions
1. Button press scale (100% → 96%)
2. Heart/Favorite toggle with fill animation
3. Input focus: border color + label float
4. Checkmark draw animation on confirmation
5. Progress stepper fill on step change
6. Toast slide-in/out

## Overlays
- Bottom sheet (filters)
- Confirmation modal
- Toast notification
- Dropdown menu

## Figma Techniques Used
- Component variants + Interactive Components
- Smart Animate with matching layer names
- Scroll behavior: fixed header / sticky nav
- Variables for conditional logic (optional)
