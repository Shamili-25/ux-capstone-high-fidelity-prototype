# Usability Test Results

## Task Results
| Task | Success Rate | Avg Time | Avg Errors | SEQ (1–7) |
|---|---|---|---|---|
| 1. Sign up | 5/5 | 48s | 0.2 | 6.4 |
| 2. Core action | 4/5 | 82s | 0.8 | 5.6 |
| 3. Change setting | 4/5 | 51s | 0.6 | 5.8 |

> ⚠️ Sample figures — replace with your own test data.

## Participant Feedback
| Participant | Quote | Task | Severity |
|---|---|---|---|
| P1 | "I wasn't sure which button was the main action." | 2 | Medium |
| P2 | "Settings icon was hard to find." | 3 | High |
| P3 | "Loved the confirmation animation." | 2 | Positive |

## Severity Scale
1 Cosmetic · 2 Minor · 3 Major · 4 Critical

## Issues & Design Fixes
| Issue | Severity | Fix Implemented |
|---|---|---|
| Primary CTA not distinct | 3 | Increased contrast, larger button |
| Settings hard to find | 3 | Moved to labeled tab in nav bar |
| Step progress unclear | 2 | Added stepper "Step 2 of 3" |

## Before / After
Add screenshots: `assets/screenshots/before-*.png`, `after-*.png`

## SUS Score
Calculated: **__ / 100** (68+ is above average)

## Learnings & Next Steps
- 
