# Usability Test Plan (Simulated)

- **Method:** Moderated, think-aloud, on Figma prototype
- **Participants:** 5 (simulated or real) matching personas
- **Duration:** 20 min each
- **Metrics:** Task success, time on task, error count, SEQ (1–7), SUS score

## Tasks
| # | Task | Success Criteria | Target Time |
|---|---|---|---|
| 1 | Sign up and reach the home screen | Reaches Home without help | < 60s |
| 2 | Find an item and complete the core action (e.g., book/order/save) | Reaches Confirmation | < 90s |
| 3 | Change a setting in Profile → Settings | Toggle changed correctly | < 45s |

## Script
1. Intro & consent
2. Warm-up questions
3. Tasks 1–3 (think aloud)
4. Post-test: SEQ per task, SUS questionnaire, open feedback
