# High-Fidelity Screens (12)

Export each from Figma at 2x PNG into `assets/screenshots/` using the file names below.

| # | Screen | File | Purpose | Key Components |
|---|---|---|---|---|
| 1 | Splash | `01-splash.png` | Brand intro | Logo, loader |
| 2 | Onboarding 1–3 | `02-onboarding.png` | Value proposition | Carousel, dots, CTA |
| 3 | Sign Up / Login | `03-auth.png` | Account access | Inputs, social buttons |
| 4 | Home / Dashboard | `04-home.png` | Overview | Cards, nav bar, search |
| 5 | Search / Explore | `05-explore.png` | Discovery | Search, filter chips, list |
| 6 | Detail Screen | `06-detail.png` | Item info | Hero image, CTA, tabs |
| 7 | Core Task Step 1 | `07-task-step1.png` | Begin main flow | Form, stepper |
| 8 | Core Task Step 2 | `08-task-step2.png` | Continue | Selection cards |
| 9 | Confirmation | `09-confirmation.png` | Success feedback | Animation, summary |
| 10 | Profile | `10-profile.png` | User info | Avatar, list items |
| 11 | Settings | `11-settings.png` | Preferences | Toggles, list |
| 12 | Empty / Error State | `12-states.png` | Edge cases | Illustration, retry CTA |

## Hi-Fi Quality Checklist
- [ ] All colors/text/spacing use tokens (no hard-coded values)
- [ ] 8-pt grid, consistent margins
- [ ] Real content (no lorem ipsum)
- [ ] Hover/pressed/disabled/error states designed
- [ ] Light & dark mode (optional bonus)
- [ ] Layers named, components used throughout
