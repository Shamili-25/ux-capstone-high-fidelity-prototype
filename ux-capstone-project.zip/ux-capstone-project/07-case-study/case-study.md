# [App Name]: [One-line Tagline]
*A UI/UX case study — [Your Name] · [Month Year]*

![Cover image](../assets/mockups/cover.png)

## Overview
| Role | Timeline | Tools | Platform |
|---|---|---|---|
| UI/UX Designer | X weeks | Figma, FigJam, Maze | Mobile |

**TL;DR:** [2–3 sentences: problem, what you did, result.]

🔗 [Interactive Prototype](PASTE_LINK) · 📄 [PDF](case-study.pdf)

## 1. The Problem
[Context + who is affected + why it matters.]

## 2. Goals & Success Metrics
- Goal 1
- Goal 2

## 3. Research
- Methods, participants, findings → see `01-research/`
- **Key insights:** 
- **Personas:** 
- **HMW questions:** 

## 4. Define & Ideate
- User flows, information architecture, sketches
- Key decisions and trade-offs

## 5. Wireframes
![Wireframes](../assets/mockups/wireframes.png)
What I explored and what I changed.

## 6. Visual Design & Design System
- Brand, color, typography, components
- ![Design System](../assets/mockups/design-system.png)
- Accessibility considerations

## 7. High-Fidelity Screens
![Screens](../assets/mockups/screens.png)
Walkthrough of key screens and rationale.

## 8. Interactive Prototype
- Smart Animate, overlays, micro-interactions
- **Try it:** [Figma Prototype](PASTE_LINK)

## 9. Usability Testing
- 3 tasks, 5 participants
- Results table, key quotes
- Issues found → fixes (before/after)

## 10. Outcome & Impact
- SUS: __ · Task success: __% 
- What improved after iteration

## 11. Reflections
- What I learned
- What I'd do differently
- Next steps

## Thank You
📧 email · 🔗 LinkedIn · 🌐 Portfolio
