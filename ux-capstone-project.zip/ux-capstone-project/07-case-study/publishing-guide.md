# Publishing Your Case Study

## Behance
1. behance.net → **Create a Project**
2. Upload cover (1400×1050 px)
3. Add content blocks in the order of `case-study.md` (Image, Text, Embed)
4. Embed prototype: Embed block → paste Figma embed URL (Figma → Share → Get embed code)
5. Add tags: UI/UX, Case Study, Figma, Mobile App
6. Publish → copy project link

## Medium
1. medium.com → Write
2. Paste `case-study.md` sections; upload images
3. Embed Figma prototype link on its own line
4. Publish → copy link

## PDF Export
- Option A: Figma → build case-study frames → File → Export frames to PDF
- Option B: Paste into Google Docs/Notion → Download as PDF
- Save as `07-case-study/case-study.pdf`
