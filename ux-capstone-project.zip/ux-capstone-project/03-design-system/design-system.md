# Design System

Tokens live in `design-tokens.json` and `tokens.css`. Replace values with your own brand palette, then mirror them as **Figma Variables / Styles**.

## Figma Setup
1. Create Variables collections: `Color`, `Spacing`, `Radius`.
2. Create Text Styles: H1, H2, H3, Body, Caption, Button.
3. Create Effect Styles: Shadow SM/MD/LG.
4. Build components with Auto Layout + Variants.

## Component Library
| Component | Variants / States |
|---|---|
| Button | Primary, Secondary, Ghost × Default, Hover, Pressed, Disabled, Loading |
| Input | Default, Focus, Filled, Error, Disabled |
| Card | Default, Elevated, Selected |
| Navigation Bar | 4 tabs, active/inactive |
| Modal / Bottom Sheet | Confirm, Form |
| Toast | Success, Error, Info |
| Toggle / Checkbox / Radio | On, Off, Disabled |
| Chips / Tags | Default, Selected |

## Accessibility Rules
- Text contrast ≥ 4.5:1 (body), ≥ 3:1 (large text)
- Touch targets ≥ 44×44 px
- Never use color alone to convey meaning
- Visible focus states
