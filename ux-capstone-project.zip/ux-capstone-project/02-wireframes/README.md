# Wireframes
Export your low-fidelity wireframes from Figma as PNG (2x) and place them here.
Naming: `wf-01-onboarding.png`, `wf-02-home.png` ...
Add a short note on what changed between wireframe and hi-fi (and why).

| Wireframe | Hi-Fi Change | Reason |
|---|---|---|
| | | |
