# Personas

## Persona 1 — [Name], [Age], [Occupation]
- **Goals:** 
- **Frustrations:** 
- **Behaviors:** 
- **Quote:** "..."
- **Tech comfort:** Low / Medium / High

## Persona 2 — [Name], [Age], [Occupation]
- **Goals:** 
- **Frustrations:** 
- **Behaviors:** 
- **Quote:** "..."

## User Flow (primary)
`Launch → Onboarding → Home → Core Task → Confirmation → Profile/History`
