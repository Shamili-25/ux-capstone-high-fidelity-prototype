# Research Summary

## Problem Statement
[Users] struggle to [do X] because [reason], resulting in [impact].

## Research Methods
| Method | Participants | Key Takeaway |
|---|---|---|
| User interviews | 5 | |
| Survey | 20 | |
| Competitor analysis | 3 apps | |

## Key Insights
1. 
2. 
3. 

## How Might We
- HMW help users [goal] without [pain point]?
- HMW make [task] faster and less stressful?

## Competitor Analysis
| Feature | Competitor A | Competitor B | Competitor C | Our App |
|---|---|---|---|---|
| Onboarding | | | | |
| Core feature | | | | |
| Accessibility | | | | |

## Design Goals
- Simple · Accessible (WCAG AA) · Delightful
