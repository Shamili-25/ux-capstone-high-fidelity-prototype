# [App Name] — High-Fidelity Prototype, Usability Case Study & Capstone

> UI/UX capstone: from wireframes to a pixel-perfect interactive Figma prototype, tested with users and documented as a full case study.

## 🔗 Proof Links (fill these in)
| Deliverable | Link |
|---|---|
| Interactive Figma Prototype | `PASTE FIGMA PROTOTYPE LINK` |
| Figma Design File (view-only) | `PASTE FIGMA FILE LINK` |
| Behance Case Study | `PASTE BEHANCE LINK` |
| Medium Article (optional) | `PASTE MEDIUM LINK` |
| PDF Case Study | [`07-case-study/case-study.pdf`](07-case-study/) |

## 📌 Project Overview
- **Role:** UI/UX Designer
- **Duration:** [X weeks]
- **Tools:** Figma, FigJam, Maze/Notion (testing), Adobe Illustrator (optional)
- **Platform:** [Mobile / Web]
- **Problem:** [One sentence]
- **Solution:** [One sentence]

## 📁 Repository Structure
```
├── 01-research/               Research summary & personas
├── 02-wireframes/             Wireframe exports (low-fi)
├── 03-design-system/          Design tokens (JSON + CSS) & component docs
├── 04-high-fidelity-screens/  Screen specs + exported PNGs (10+ screens)
├── 05-prototype/              Interaction map, animations, Figma link
├── 06-usability-test/         Test plan, 3 tasks, results & fixes
├── 07-case-study/             Behance/Medium-ready case study + PDF
└── assets/                    Screenshots, mockups, exports
```

## ✅ Capstone Checklist
- [ ] Design system tokens applied (`03-design-system/`)
- [ ] 10+ high-fidelity screens (`04-high-fidelity-screens/`)
- [ ] Interactive prototype with smart animate, overlays, micro-interactions (`05-prototype/`)
- [ ] Usability test: 3 tasks + feedback documented (`06-usability-test/`)
- [ ] Case study published on Behance/Medium + PDF (`07-case-study/`)
- [ ] All links filled in above
